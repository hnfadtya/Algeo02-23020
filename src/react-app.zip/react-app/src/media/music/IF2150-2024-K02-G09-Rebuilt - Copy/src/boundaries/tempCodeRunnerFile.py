rightProyekFrame = ttk.Frame(proyekDetailFrame)
        rightProyekFrame.grid(row=0, column=1, sticky="nsew")