# import setup_env  # ini tolong hapus ini ada cuma gara gara python gue fucked up

from MainApplication import MainApp  # Ensure the capitalization matches the filename.

def main():
    app = MainApp()
    app.mainloop()

if __name__ == "__main__":
    main()
